#include "stdafx.h"
#include "Scene.h"

int Scene::selected = 0;
bool Scene::isChanged = false;