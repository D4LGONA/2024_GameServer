#pragma once
#ifndef _Image
#define _Image

class Image
{
public :
	CImage img;
	RECT rc;
};

#endif
